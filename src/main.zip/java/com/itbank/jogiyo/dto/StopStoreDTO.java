package com.itbank.jogiyo.dto;

public class StopStoreDTO {
    private int storeid;
    private String selectDatetime;

    public int getStoreid() {
        return storeid;
    }

    public void setStoreid(int storeid) {
        this.storeid = storeid;
    }

    public String getSelectDatetime() {
        return selectDatetime;
    }

    public void setSelectDatetime(String selectDatetime) {
        this.selectDatetime = selectDatetime;
    }
}